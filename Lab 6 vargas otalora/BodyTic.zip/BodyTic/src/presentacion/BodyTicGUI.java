package presentacion;

import aplicacion.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.Thread;
import java.io.*;


import aplicacion.*;


public class BodyTicGUI extends JFrame {

    private Salon salon = null;

    private JPanel botones;
    private JScrollPane contenedor;
    private JButton botonEntrada;
    private JButton botonSalida;
    private JButton botonInicio;
    private JButton botonParada;
    private JButton botonDecision;
    private FotoSalon foto;

    private JMenuBar menuBar;
    private JMenu menu;
    private JMenuItem abrir;
    private JMenuItem salir;
    private JMenuItem salvarComo;
    private JMenuItem exportar;
    private JMenuItem importar;
    private JMenuItem importar02;
    private JMenuItem iniciar;

    public BodyTicGUI() {
        super("Body Tic");
        prepareElementosMenu();
        try {
            salon = Salon.demeSalon();
            elementos();
            acciones();
        } catch (Exception e) {
            e.printStackTrace();
        }
        prepareAcciones();
    }

    private void prepareElementosMenu(){
        menuBar = new JMenuBar();
        menu = new JMenu("Menu");
        abrir = new JMenuItem("Abrir");
        salir = new JMenuItem("Salir");
        salvarComo = new JMenuItem("Salvar");
        exportar = new JMenuItem("Exportar");
        importar = new JMenuItem("Importar");
        importar02 = new JMenuItem("Importar02");
        iniciar = new JMenuItem("Iniciar"); 
        menu.add(abrir);menu.add(salvarComo);menu.add(abrir);
        menu.add(exportar);menu.add(importar);menu.add(salir);
        menu.add(importar02);
        menu.add(iniciar);
        menuBar.add(menu);
        setJMenuBar(menuBar);
    }

    private void prepareAcciones(){
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE );
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                salga();
            }
        });

        salvarComo.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            	guardarComo();
            }
        });

        abrir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            		abrir();
            }
        });


        salir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                salga();
            }
        });

        importar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	opcionImportar();
            }
        });
        importar02.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	opcionImportar02();
            }
        });
        exportar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	opcionExportar();
            }
        });
        iniciar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	salida();
            }
        });
    }

    private void elementos() throws Exception {
        
        setLayout(new BorderLayout());    
        contenedor = new JScrollPane();
        
        foto= new FotoSalon();
        contenedor.getViewport().add(foto);
        
        botones=new JPanel(new GridLayout(1,2));
        botonEntrada=new JButton("Entren");
        botonInicio=new JButton("Inicien");
        botonParada=new JButton("Paren");
        botonDecision=new JButton("Decidan");          
        botonSalida=new JButton("Salgan");
        
        botones.add(botonEntrada);
        botones.add(botonInicio);
        botones.add(botonParada);
        botones.add(botonDecision);        
        botones.add(botonSalida);        
        
        add(contenedor,BorderLayout.CENTER);
        add(botones,BorderLayout.SOUTH);
        
        pack();
        setSize(Salon.MAXIMO+100,Salon.MAXIMO+135);

        setResizable(false);
    }
    
    
    private void acciones(){
        
        ActionListener oyenteBotonEntrada=new ActionListener(){
            public void actionPerformed(ActionEvent e){
                entrada();
            }   
        };  
        botonEntrada.addActionListener(oyenteBotonEntrada);
        
        ActionListener oyenteBotonInicio=new ActionListener(){
            public void actionPerformed(ActionEvent e){
                inicio();
            }   
        };  
        botonInicio.addActionListener(oyenteBotonInicio);
        
        ActionListener oyenteBotonParada=new ActionListener(){
            public void actionPerformed(ActionEvent e){
                parada();
            }   
        };  
        botonParada.addActionListener(oyenteBotonParada);
        
        ActionListener oyenteBotonDecision=new ActionListener(){
            public void actionPerformed(ActionEvent e){
                decision();
            }   
        };  
        botonDecision.addActionListener(oyenteBotonDecision);
        
        ActionListener oyenteBotonSalida=new ActionListener(){
            public void actionPerformed(ActionEvent e){
                salida();
            }   
        };  
        botonSalida.addActionListener(oyenteBotonSalida);
        
        WindowListener w = new WindowAdapter() { 
            public void windowClosing(WindowEvent e) {
                salga();
            }
        };  
        this.addWindowListener(w);
        
    }   
    
    
    private void entrada(){
         salon.entrada();
         foto.actualice();
    }
    
    private void salida(){
         salon.salida();
         foto.actualice();
    }
    
    private void inicio(){
         salon.inicio();
         foto.actualice();
    }
        
    
    private void parada(){       
        salon.parada();
        foto.actualice();
    }       
  
    private void decision() {
        salon.decision();
        foto.actualice();
    }
    
    
    public static void main(String[] args) {
        BodyTicGUI gui=new BodyTicGUI();
        gui.setVisible(true);
    }   
    
    
    private class FotoSalon extends JComponent {
        private int x,y;
        
        private static final int MAX=Salon.MAXIMO;
        
        
        public void actualice(){
            salon=Salon.demeSalon();
            repaint();
        }
        
        public void paintComponent(Graphics g){
            g.setFont(new Font("TimesRoman", Font.PLAIN, 8));
            for (int i=1; i<=salon.numeroEnSalon(); i++) {
                EnSalon e=salon.deme(i);
                int x=e.getPosicionX();
                int y=MAX-e.getPosicionY();
                g.setColor(e.getColor()); 
                g.drawString(e.mensaje(),x+20,y+10);
                if (e.forma().equals("Persona")){
                    humano(g,(Persona)e,x,y);
                } else  if (e.forma().equals("Circulo")){
                    g.fillOval(x+10,y+0,25,25);
                } else  if (e.forma().equals("Cuadrado")){
                    g.fillRect(x-22,y,1000,50);
                }
            }
            super.paintComponent(g);
        }
        
        
        public void humano(Graphics g, Persona e,int x, int y){
            int pos;
            g.setColor(Color.PINK);
            g.fillOval(x+10,y+0,10,10);/*cabeza*/
            g.setColor(e.getColor()); 
            g.drawLine(x+10+5,y+10,x+10+5,y+10+20);
            
            pos=e.getPosicionBrazo('I');
            if (pos==Persona.ARRIBA){
                g.drawLine(x+10+5,y+10+5,x+10+15,y+10);/*brazo izq arriba*/
            } else if (pos==Persona.FRENTE){
                g.drawLine(x+10+5,y+10+5,x+10+15,y+10+5);/*brazo izq al frente*/
            } else {
                g.drawLine(x+10+5,y+10+5,x+10+15,y+10+10);/*brazo izq abajo*/
            }
            
            pos=e.getPosicionBrazo('D');
            if (pos==Persona.ARRIBA){
                g.drawLine(x+10+5,y+10+5,x+5,y+10);/*brazo der arriba*/
            } else if  (pos==Persona.FRENTE){
                g.drawLine(x+10+5,y+10+5,x+5,y+10+5);/*brazo der al frente*/
            } else{
                g.drawLine(x+10+5,y+10+5,x+5,y+10+10);/*brazo der abajo*/
            }
            
            g.drawLine(x+10+5,(y+15)+10+5,x+10+15,(y+15)+10+15);
            g.drawLine(x+10+5,(y+15)+10+5,x+5,(y+15)+10+15);
            
           pos=e.getPosicionPierna('D');
            if (pos==Persona.ARRIBA){
                g.drawLine(x+5,(y+15)+10+15,x+5+10,(y+15)+10+15);/*pierna der arriba*/
            } else if  (pos==Persona.FRENTE){
                g.drawLine(x+5,(y+15)+10+15,x+5-10,(y+15)+10+15+5);/*pierna der al frente*/
            } else{
                g.drawLine(x+5,(y+15)+10+15,x+5,(y+15)+10+15+10);/*pierna der abajo*/
            }
            
            pos=e.getPosicionPierna('I');
            if (pos==Persona.ARRIBA){
                g.drawLine(x+10+15,(y+15)+10+15,x+10+15-10,(y+15)+10+15);/*pierna izq arriba*/
            } else if  (pos==Persona.FRENTE){
                g.drawLine(x+10+15,(y+15)+10+15,x+10+15+10,(y+15)+10+15+5);/*pierna izq al frente*/
            }else {
                g.drawLine(x+10+15,(y+15)+10+15,x+10+15,(y+15)+10+15+10);/*piernaizqabajo*/
            }
        }
    }

    private void salga(){
        salon.salga();
    }




    /**
     * permite guardar una partida
     */
    private void abrir() {
    	 JFileChooser file= new JFileChooser();
    	 file.setDialogTitle("archivos a elegir");
    	 file.setFileSelectionMode(JFileChooser.FILES_ONLY);
    	 if(file.showOpenDialog(abrir)== JFileChooser.APPROVE_OPTION) {
    	  File nombre = file.getSelectedFile();
    	  try {
    	   salon.abrir(nombre.toString());
    	   foto.actualice();
    	  }catch(bodyTicException e ) {
    	   JOptionPane.showMessageDialog(this, e.getMessage());
    	  }
    	 }
    	}
    
    private void guardarComo(){
    	 JFileChooser file= new JFileChooser();
    	 file.setSelectedFile(new File("save.dat")); 
    	 if(file.showSaveDialog(salvarComo)==JFileChooser.APPROVE_OPTION) {
    	    File nombre = file.getSelectedFile();
    	    try {
    	    salon.guardar(nombre.toString());
    	    }catch(bodyTicException e) {
    	     JOptionPane.showMessageDialog(this, "No se puedo gruardar");
    	    }
    	    
    	  }
    	 }

     private void opcionExportar(){
    	 JFileChooser file= new JFileChooser();
    	 file.setSelectedFile(new File("save.dat")); 
    	 if(file.showSaveDialog(salvarComo)==JFileChooser.APPROVE_OPTION) {
    	    File nombre = file.getSelectedFile();
    	    try {
    	    salon.exporte(nombre.toString());
    	    }catch(bodyTicException e) {
    	     JOptionPane.showMessageDialog(this, "No se puedo gruardar");
    	    }
    	    
    	  }
    	 }
    
     private void opcionImportar() {
    	 JFileChooser file= new JFileChooser();
    	 file.setDialogTitle("archivos a elegir");
    	 file.setFileSelectionMode(JFileChooser.FILES_ONLY);
    	 if(file.showOpenDialog(abrir)== JFileChooser.APPROVE_OPTION) {
    	  File nombre = file.getSelectedFile();
    	  try {
    	   salon.importar(nombre.toString());
    	   foto.actualice();
    	  }catch(bodyTicException e ) {
    	   JOptionPane.showMessageDialog(this, e.getMessage());
    	  }
    	 }
    	}
     
     private void opcionImportar02() {
    	 JFileChooser file= new JFileChooser();
    	 file.setDialogTitle("archivos a elegir");
    	 file.setFileSelectionMode(JFileChooser.FILES_ONLY);
    	 if(file.showOpenDialog(abrir)== JFileChooser.APPROVE_OPTION) {
    	  File nombre = file.getSelectedFile();
    	  try {
    	   salon.importar02(nombre.toString());
    	   foto.actualice();
    	  }catch(BodyTicExceptionCompilador e ) {
    	   JOptionPane.showMessageDialog(this, e.getMessage());
    	  } catch (bodyTicException e) {
    	   JOptionPane.showMessageDialog(this, e.getMessage());
		}
    	 }
    	}
}






