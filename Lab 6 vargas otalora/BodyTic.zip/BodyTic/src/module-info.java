/**
 * 
 */
/**
 * @author davidandres
 *
 */
module BodyTic {
	exports presentacion;
	exports aplicacion;
	requires java.desktop;
}