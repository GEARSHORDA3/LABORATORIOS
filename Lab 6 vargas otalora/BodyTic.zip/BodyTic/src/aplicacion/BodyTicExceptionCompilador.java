package aplicacion;


public class BodyTicExceptionCompilador extends Exception {
	
	public final static String FUERALIMITE = "El archivo a  importar tiene un elemento en una posicion incorrecta de la lista";
	public final static String ESTADONOBOOLEANO = "El archivo a importar tiene un elemento con  estado no booleano";
	public final static String INDICENONUMERICO = "El archivo a importar tiene indices no numericos el  elemento";
	public final static String CLASENOENCONTRADA = "El archivo a importar tiene un nombre de clase no definido";;
	public final static String FALTANELEMENTOS = "El archivo a importar no tiene numero correcto de instrucciones";
	public final static String NOMBREBOOLEANO = "El archivo a importar tiene un booleano enves del nombre";
	public final static String NOMBRENUMERICO = "El archivo a importar tiene un numero  enves del nombre";

	public BodyTicExceptionCompilador(String mensaje,int line){
		super("En la linea "+line+" "+mensaje);
	}
}
