package aplicacion;

import java.io.Serializable;

/**
 * Write a description of class SuperDeportista here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DeportistasAvanzados extends Deportista implements EnSalon,Serializable
{
    private Salon salon;   
    protected String palabras;
    protected int paso;
    private int conta;
    /**
     * Constructor for objects of class SuperDeportista
     */
    public DeportistasAvanzados(Salon salon,String nombre,int posicionx, int posiciony)
    {
        super(salon,nombre,posicionx,posiciony, 1);
    }
    
    /**iniciar el movimiento del DeportistasAvanzados sobreescribiendolo*/
    public void inicie(){
        super.PASO=60;
        super.inicie();
        conta+=1;
    }
    public String getClase(){
        return "Avanzado";
    }
}
