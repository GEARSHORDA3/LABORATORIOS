package aplicacion;


import java.io.*;
import javax.swing.*;

import java.util.*;


/**
 * @author ECI 2014
 * Salon de la aplicación egiptologos
 */
/**
 * @author ECI
 *
 */
public class Salon implements Serializable{
        public static final int MAXIMO = 500;
        private static Salon salon = null;
        private ArrayList<EnSalon> elementos;
        private int conta=0;
        public static Salon demeSalon() {
            if (salon==null){
                salon=new Salon();
            }
            return salon;
        }
        
        /**crear un nuevo salon*/
        public static void nuevoSalon() {
            salon=new Salon();
        }   
        
        /**cambiar entre salones*/
        public static void cambieSalon(Salon d) {
            salon=d;
        }       
        
        /**crear una lista de todos los salones que existan*/
        public Salon() {
            elementos= new ArrayList<EnSalon>();
        }
        
        /**buscar un salon sino es nulo*/
        public EnSalon deme(int n){
            EnSalon h=null;
            if (1<=n && n<=elementos.size()){
                h=elementos.get(n-1);
            }    
            return h; 
        }
    
        /**adicionar salones a la lista elementos*/
        public void adicione(EnSalon e){
            elementos.add(e);
        }
    
        /**retornar la cantidad de salones existentes con un entero*/
        public int numeroEnSalon(){
            return elementos.size();
        }
    
        /**crear todos los objetos de los salones*/
        public void entrada(){  
            PistaDeBaile Bass = new PistaDeBaile(salon,20,-20);
            Bola bol = new Bola(salon,40,10);
            Bola bol2 = new Bola(salon,480,410);
            elementos.add(bol);
            elementos.add(bol2);
            elementos.add(Bass);
            Deportista edward = new Deportista(salon,"edward",250,50,0);
            Deportista bella = new Deportista(salon, "bella",200,50,0);
            DeportistasAvanzados neo = new DeportistasAvanzados(salon,"neo",250,150);
            DeportistasAvanzados trinity = new DeportistasAvanzados(salon, "trinity",200,150);
            DeportistasHabladores han = new DeportistasHabladores(salon,"han",200,250);
            DeportistasHabladores leila = new DeportistasHabladores(salon,"leila",300,250);
            DeportistaSalsero David = new  DeportistaSalsero(salon,"David",420,150); 
            DeportistaSalsero Andres = new  DeportistaSalsero(salon,"Andres",20,150); 
        }  
        
        /**quitar todos los elemntos existentes de los salones*/
        public void salida(){
            elementos.clear();
        }
        
        /**poner en moviminto todos los elemntos de todos los salones*/
       public void inicio(){              
           for (int i=0; i<elementos.size(); i++){
               elementos.get(i).inicie();}             
       }    
       
       /**parar el movimiento que esten realizando los objetos de elementos*/
       public void parada(){
           for (int i=0; i<elementos.size(); i++){
               if (i!=2 || i!=3){
                   elementos.get(i).pare();
               }
           }           
           if (conta % 3==0 && elementos.size()>3){
               elementos.get(2).pare();
               elementos.get(3).pare();                  
           }
           conta+=1;
       }    
       
       /**poner en moviminto todos los elemntos de todos los salones*/
       public void decision(){
           for (int i=0; i<elementos.size(); i++){
               elementos.get(i).decida();
           }
       }

    public void salga(){
        int c = JOptionPane.showConfirmDialog(null,"Desea salir?","EXIT",JOptionPane.YES_NO_OPTION);
        if (JOptionPane.YES_OPTION == c) {
            System.exit(1);
        }
    }
    
    /**
     * exportar un archivo con cadenas de los objetos 
     * @param Archivo
     */
    public void exporte(String Archivo) throws bodyTicException{
    	try {
    		PrintWriter archivo = new PrintWriter(new FileOutputStream(Archivo));
    		for(EnSalon i: elementos) {
    			archivo.println(i.getClase()+" "+i.getPosicionX()+" "+i.getPosicionY()+" "+i.getNombre());
    		}
    		archivo.close();
    		}catch (Exception e) {
    			throw new bodyTicException(bodyTicException.ErrorExtraer);
    		}
    }
    
    /**
     * exportar un archivo con cadenas de los objetos 
     * @param Archivo
     */
    public void exporte01(String Archivo) throws bodyTicException{
    	try {
    		PrintWriter archivo = new PrintWriter(new FileOutputStream(Archivo));
    		for(EnSalon i: elementos) {
    			archivo.println(i.getClase()+" "+i.getPosicionX()+" "+i.getPosicionY()+" "+i.getNombre());
    		}
    		archivo.close();
    		}catch (Exception e) {
    			throw new bodyTicException(bodyTicException.ErrorExtraer);
    		}
    }
    
    /**
     * importar un archivo con cadenas de los objetos 
     * @param Archivo
     */
    public void importar(String Archivo) throws bodyTicException{
    	try {
    		BufferedReader archivo = new BufferedReader(new FileReader(Archivo));
    		String linea = archivo.readLine();
    		String[] lista;
    		salon = new Salon();
    		while(linea != null) {
    			linea = linea.trim();
    			lista=linea.split(" ");
    			if(lista[0].equals("Bola")){
    				Bola d = new Bola(salon,Integer.parseInt(lista[1]),Integer.parseInt(lista[2]));
    				elementos.add(d);
    			}
    			else if(lista[0].equals("PistaDeBaile")){
    				elementos.add(new PistaDeBaile(salon,Integer.parseInt(lista[1]),Integer.parseInt(lista[2])));
    			}
    			else if(lista[0].equals("Deportista")){
    				elementos.add(new Deportista(salon,lista[3],Integer.parseInt(lista[1]),Integer.parseInt(lista[2]),0));
    			}
    			else if(lista[0].equals("Avanzado")){
    				elementos.add(new DeportistasAvanzados(salon,lista[3],Integer.parseInt(lista[1]),Integer.parseInt(lista[2])));
    			}
    			else if(lista[0].equals("Hablador")){
    				elementos.add(new DeportistasHabladores(salon,lista[3],Integer.parseInt(lista[1]),Integer.parseInt(lista[2])));
    			}
    			else if(lista[0].equals("Salsero")){
    				elementos.add(new DeportistaSalsero(salon,lista[3],Integer.parseInt(lista[1]),Integer.parseInt(lista[2])));
    			}
    			linea=archivo.readLine();
    		}
    		
    		}catch (IOException e) {
    			throw new bodyTicException(bodyTicException.ErrorImportar);
    		}
    }
    
    /**
     * importar un archivo con cadenas de los objetos 
     * @param Archivo
     */
    public void importar01(String Archivo) throws bodyTicException{
    	try {
    		BufferedReader archivo = new BufferedReader(new FileReader(Archivo));
    		String linea = archivo.readLine();
    		String[] lista;
    		salon = new Salon();
    		while(linea != null) {
    			linea = linea.trim();
    			lista=linea.split(" ");
    			if(lista[0].equals("Bola")){
    				Bola d = new Bola(salon,Integer.parseInt(lista[1]),Integer.parseInt(lista[2]));
    				elementos.add(d);
    			}
    			else if(lista[0].equals("PistaDeBaile")){
    				elementos.add(new PistaDeBaile(salon,Integer.parseInt(lista[1]),Integer.parseInt(lista[2])));
    			}
    			else if(lista[0].equals("Deportista")){
    				elementos.add(new Deportista(salon,lista[3],Integer.parseInt(lista[1]),Integer.parseInt(lista[2]),0));
    			}
    			else if(lista[0].equals("Avanzado")){
    				elementos.add(new DeportistasAvanzados(salon,lista[3],Integer.parseInt(lista[1]),Integer.parseInt(lista[2])));
    			}
    			else if(lista[0].equals("Hablador")){
    				elementos.add(new DeportistasHabladores(salon,lista[3],Integer.parseInt(lista[1]),Integer.parseInt(lista[2])));
    			}
    			else if(lista[0].equals("Salsero")){
    				elementos.add(new DeportistaSalsero(salon,lista[3],Integer.parseInt(lista[1]),Integer.parseInt(lista[2])));
    			}
    			linea=archivo.readLine();
    		}
    		
    		}catch (IOException e) {
    			throw new bodyTicException(bodyTicException.ErrorImportar);
    		}
    }
    
    /**
     * guardar un archivo con con el formato predeterminado de java 
     * @param nombreArchivo
     */
    public void guardar(String nombreArchivo)throws bodyTicException{
        try {
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(nombreArchivo));
        salida.writeObject(this);
        salida.close();
        }catch (Exception e) {
         throw new bodyTicException(bodyTicException.ERRORALGUARDAR);
    }
    } 
    
    
    /**
     * abrir un archivo con con el formato predeterminado de java 
     * @param nombreArchivo
     */
    public void abrir(String nombreArchivo) throws bodyTicException{
        try {
         ObjectInputStream documento = new ObjectInputStream(new FileInputStream(nombreArchivo));
         salon = (Salon)documento.readObject();
        }catch (Exception e) {
         JOptionPane.showMessageDialog(null, this, e.getMessage(), 0);
     throw new bodyTicException(bodyTicException.ERRORALABRIR);
    }
    }
    
    /**
     * abrir un archivo con con el formato predeterminado de java 
     * @param nombreArchivo
     */
    public void abrir01(String nombreArchivo) throws bodyTicException{
        try {
         ObjectInputStream documento = new ObjectInputStream(new FileInputStream(nombreArchivo));
         salon = (Salon)documento.readObject();
        }catch (Exception e) {
         JOptionPane.showMessageDialog(null, this, e.getMessage(), 0);
     throw new bodyTicException(bodyTicException.ERRORALABRIR);
    }
    }
       
    /**
     * guardar un archivo con con el formato predeterminado de java 
     * @param nombreArchivo
     */
    public void guardar01(String nombreArchivo)throws bodyTicException{
        try {
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(nombreArchivo));
        salida.writeObject(this);
        salida.close();
        }catch (Exception e) {
         throw new bodyTicException(bodyTicException.ERRORALGUARDAR);
    }
	}	
    
    /**
     * importar un archivo con cadenas de los objetos  con unas excepciondes especificas con el compilador
     * @param Archivo
     */
    public void importar02(String nombreArchivo) throws BodyTicExceptionCompilador,bodyTicException{
    	try {
	    	BufferedReader archivo= new BufferedReader(new FileReader(nombreArchivo));
	    	String linea=archivo.readLine();
	    	String[] lista;
	    	salon=new Salon();
	    	int numeroLinea=0;
	    	while(linea != null) {
	    		linea=linea.trim();
	    		lista=linea.split(" ");
	    		compilador(lista, numeroLinea);
	    		if (lista[0].equals("Hablador")) elementos.add(new DeportistasHabladores(salon, lista[3], Integer.parseInt(lista[1]), Integer.parseInt(lista[2])));
	    		else if (lista[0].equals("Avanzado")) elementos.add(new DeportistasAvanzados(salon, lista[3], Integer.parseInt(lista[1]), Integer.parseInt(lista[2])));
	    		else if (lista[0].equals("Principiante")) elementos.add(new DeportistaSalsero(salon, lista[3], Integer.parseInt(lista[1]), Integer.parseInt(lista[2])));
	    		else if (lista[0].equals("Deportista")) elementos.add(new Deportista(salon, lista[3], Integer.parseInt(lista[1]), Integer.parseInt(lista[2]),0));
	    		else if (lista[0].equals("Bola")) elementos.add(new Bola(salon, Integer.parseInt(lista[1]), Integer.parseInt(lista[2])));
	    		else if (lista[0].equals("Cajadesalto")) elementos.add(new PistaDeBaile(salon, Integer.parseInt(lista[1]), Integer.parseInt(lista[2])));
	    		else throw new BodyTicExceptionCompilador(BodyTicExceptionCompilador.CLASENOENCONTRADA, numeroLinea);
	    		linea=archivo.readLine();
	    		++numeroLinea;
	    	}
    	}catch (IOException  e) {
    		throw new bodyTicException(bodyTicException.ErrorImportar);
    	}
    }
    
    /**
     * compilador con condiciones especiales de excepciones
     * @param line
     * @param numeLine
     */
    public void compilador(String[] line,int numeLine) throws BodyTicExceptionCompilador{
    	if (verificarNum(line[0]))
    		throw new BodyTicExceptionCompilador(BodyTicExceptionCompilador.NOMBRENUMERICO,numeLine);
    	if (!verificarNum(line[1]) || !verificarNum(line[2]))
    		throw new BodyTicExceptionCompilador(BodyTicExceptionCompilador.INDICENONUMERICO,numeLine);
    	if (Integer.parseInt(line[1])<0 || Integer.parseInt(line[2])<0)
    		throw new BodyTicExceptionCompilador(BodyTicExceptionCompilador.FUERALIMITE,numeLine);
    	if (line.length!=3 && line.length!=4)
    		throw new BodyTicExceptionCompilador(BodyTicExceptionCompilador.FALTANELEMENTOS,numeLine);
    	if (line[0].equals("true") || line[0].equals("false"))
    		throw new BodyTicExceptionCompilador(BodyTicExceptionCompilador.NOMBREBOOLEANO,numeLine);
    }
    
    /**
     * compilador con condiciones especiales de excepciones
     * @param line
     * @param numeLine
     */
    public boolean verificarNum(String cadena){
		boolean valida=true;
    	try{
    		int n=Integer.parseInt(cadena);
    	}catch(NumberFormatException e){
    		valida=false;
    	}
    	return valida;
    	}



    
}
