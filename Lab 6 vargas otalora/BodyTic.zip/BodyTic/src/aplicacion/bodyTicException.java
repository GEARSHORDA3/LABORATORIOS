package aplicacion;

public class bodyTicException extends Exception{

    public static final String  GUARDAR="Opcion guardar esta en construccion";
    public static final String  ABRIR ="Opcion abrir esta en construccion";
    public static final String EXPORTAR="Opcion exportar esta en construccion";
    public static final String IMPORTAR="Opcion importar esta en construccion";
    public static final String ERRORALABRIR = "error abrir";
    public static final String ERRORALGUARDAR = "El archivo debe ser de tipo DATA(.dat)";
    public static final String SALONVACIO = "No hay elementos en el salon";
    public static final String ErrorExtraer="Error a extraer ";
    public static final String ErrorImportar="Error al importar ";
    public bodyTicException(String message){
        super(message);
    }

}
